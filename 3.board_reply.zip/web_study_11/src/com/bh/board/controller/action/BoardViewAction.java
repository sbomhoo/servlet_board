package com.bh.board.controller.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bh.dao.BoardDAO;
import com.bh.dto.BoardVO;

public class BoardViewAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/board/boardView.jsp";

		String num = request.getParameter("num");

		BoardDAO bDao = BoardDAO.getInstance();

		bDao.updateReadCount(num);

		BoardVO bVo = bDao.selectOneBoardByNum(num);
		System.out.println(bVo.toString());
		request.setAttribute("board", bVo); // request로 보내는 정보

		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);




	}
}
